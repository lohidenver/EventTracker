package com.skilldistillery.todoapp.entities;

public class Todo {

}
